SRISHTI BIRTHDAY WEBSITE — 26 OCTOBER 2026

OPEN LOCALLY:
1. Extract this ZIP.
2. Open index.html in a modern browser. Some phones may not play music automatically; this build does not include a song because no audio file was uploaded.

PERSONAL MEDIA:
- Four uploaded display photos are included unchanged in assets/photos.
- Two original DNG files are also included unchanged for safekeeping; browsers generally cannot display DNG directly.
- The four non-photo slides are animated designs. No original video files were attached yet.
- Original photo/video assets are not recompressed by this project.

FREE PUBLIC HOSTING WITH GITHUB PAGES (Android):
1. Extract ZIP using Files by Google or another archive app.
2. Visit github.com and sign in/create a free account.
3. Create a NEW PUBLIC repository named srishti-birthday.
4. Upload the contents of the extracted folder (index.html, style.css, script.js, README.txt and assets folder). Do not upload only the ZIP.
5. In the repository, open Settings > Pages.
6. Under Build and deployment, choose Deploy from a branch, select main and /(root), then Save.
7. Wait for the Pages URL to appear in Settings > Pages. Share that URL.

PRIVACY NOTE: A public repository makes the uploaded site and media publicly accessible. Do not upload anything you want to keep private.

MUSIC: No song was provided. Add a licensed/owned audio file and a music player if you want background music. Browsers usually require a tap before audio can start.
